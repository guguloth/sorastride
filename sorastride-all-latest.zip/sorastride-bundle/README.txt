SoraStride — all plugins and theme (latest, 21 Nov 2026)

Each zip inside is installed on its own (WordPress cannot install this outer zip).
Plugins: Plugins > Add New > Upload Plugin > choose zip > "Replace current with uploaded".
Theme:   Appearance > Themes > Add New > Upload Theme > sorastride-theme.zip > "Replace current".

  sorastride-ship.zip    SoraStride Ship   2.56.0   Bitrix24 card -> Shiprocket (order, AWB, pickup, tracking)
  sarasync.zip           SaraSync          0.40.1   WooCommerce <-> Bitrix24 (deals, Mode of Payment, catalog)
  sorastride-fit.zip     SoraStride Fit    2.57.1   product page, checkout, Razorpay details
  sorastride-media.zip   SoraStride Media  1.1.1    media gallery
  sorastride-theme.zip   SoraStride theme  4.1.8    Storefront child theme (folder: sorastride)

Settings are kept on update. Folder names are unchanged, so each one replaces the installed copy.
